# CopyPasta
Chrome extension to send links to discord channel using webhook and chrome context menu
